import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/service_model.dart';

class Booking {
  final String id, service, area, problem, type, status;
  final int charge;
  final DateTime createdAt;
  Booking({required this.id,required this.service,required this.area,required this.problem,required this.type,required this.status,required this.charge,required this.createdAt});
}

class AppState extends ChangeNotifier {
  bool loggedIn=false, isTechnician=false, isAdmin=false, available=true;
  String userName='Guest', phone='';
  Booking? activeBooking;
  final List<Booking> bookings=[];
  final services=const [
    ServiceModel('Electrician',Icons.electrical_services,'Electrical repair & installation'),
    ServiceModel('Plumber',Icons.plumbing,'Pipes, taps & water issues'),
    ServiceModel('CCTV Camera',Icons.videocam,'Installation & troubleshooting'),
    ServiceModel('Welder',Icons.handyman,'Welding & fabrication'),
    ServiceModel('House Painter',Icons.format_paint,'Interior & exterior painting'),
    ServiceModel('AC Technician',Icons.ac_unit,'AC service & repair'),
    ServiceModel('Carpenter',Icons.carpenter,'Woodwork & furniture'),
    ServiceModel('Solar',Icons.solar_power,'Solar installation & maintenance'),
  ];

  Future<void> login(String name,String mobile) async {loggedIn=true;userName=name.isEmpty?'Customer':name;phone=mobile;final p=await SharedPreferences.getInstance();await p.setBool('loggedIn',true);await p.setString('name',userName);await p.setString('phone',phone);notifyListeners();}
  Future<void> restore() async {final p=await SharedPreferences.getInstance();loggedIn=p.getBool('loggedIn')??false;userName=p.getString('name')??'Guest';phone=p.getString('phone')??'';notifyListeners();}
  Future<void> logout() async {loggedIn=false;final p=await SharedPreferences.getInstance();await p.clear();notifyListeners();}
  int chargeFor(String area,String type){final base={'Malir':500,'Saudabad':550,'Model Colony':600,'Shah Faisal':650,'Other':750}[area]??750;return type=='Emergency'?base+500:type=='Urgent'?base+250:base;}
  String createBooking(String service,String area,String problem,String type){final id='#AA${const Uuid().v4().substring(0,6).toUpperCase()}';final b=Booking(id:id,service:service,area:area,problem:problem,type:type,status:type=='Emergency'?'Emergency Request Sent':'Booking Received',charge:chargeFor(area,type),createdAt:DateTime.now());activeBooking=b;bookings.insert(0,b);notifyListeners();return id;}
  void advanceBooking(){if(activeBooking==null)return;const steps=['Booking Received','Technician Assigned','On The Way','Arrived','Work Completed'];final i=steps.indexOf(activeBooking!.status);if(i<steps.length-1&&i>=0){activeBooking=Booking(id:activeBooking!.id,service:activeBooking!.service,area:activeBooking!.area,problem:activeBooking!.problem,type:activeBooking!.type,status:steps[i+1],charge:activeBooking!.charge,createdAt:activeBooking!.createdAt);bookings[0]=activeBooking!;notifyListeners();}}
  void setTechnicianMode(bool v){isTechnician=v;isAdmin=false;notifyListeners();}
  void setAdminMode(bool v){isAdmin=v;isTechnician=false;notifyListeners();}
}
