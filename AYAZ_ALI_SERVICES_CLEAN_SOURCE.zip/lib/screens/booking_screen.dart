import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import '../theme/app_theme.dart';
import 'tracking_screen.dart';

class BookingScreen extends StatefulWidget {
  final String service;
  final bool emergency;

  const BookingScreen({
    super.key,
    required this.service,
    this.emergency = false,
  });

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final problem = TextEditingController();
  String area = 'Malir';
  String type = 'Normal';

  @override
  void initState() {
    super.initState();
    if (widget.emergency) {
      type = 'Emergency';
    }
  }

  @override
  void dispose() {
    problem.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final charge = context.watch<AppState>().chargeFor(area, type);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.emergency ? 'Emergency Request' : 'Book a Service',
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            widget.service,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: problem,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Describe Your Problem',
              hintText: 'Example: Light / switch issue',
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: area,
            decoration: const InputDecoration(labelText: 'Select Area'),
            items: const [
              'Malir',
              'Saudabad',
              'Model Colony',
              'Shah Faisal',
              'Other',
            ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (value) {
              if (value != null) setState(() => area = value);
            },
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: type,
            decoration: const InputDecoration(labelText: 'Service Type'),
            items: const [
              'Normal',
              'Urgent',
              'Emergency',
            ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (value) {
              if (value != null) setState(() => type = value);
            },
          ),
          const SizedBox(height: 20),
          Card(
            child: ListTile(
              title: const Text('Estimated Visit Charge'),
              subtitle: const Text(
                'Final work/material charges can be agreed with technician',
              ),
              trailing: Text(
                'Rs. $charge',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.blue,
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: () => _confirmBooking(charge),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.gold,
                foregroundColor: AppTheme.navy,
              ),
              child: const Text(
                'CONFIRM BOOKING',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmBooking(int charge) {
    final description = problem.text.trim();
    if (description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please describe your problem')),
      );
      return;
    }

    final id = context.read<AppState>().createBooking(
      widget.service,
      area,
      description,
      type,
    );

    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Booking Confirmed'),
          content: Text(
            'Your request has been received.\n'
            'Booking ID: $id\n'
            'Visit Charge: Rs. $charge',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const TrackingScreen(),
                  ),
                );
              },
              child: const Text('VIEW BOOKING'),
            ),
          ],
        );
      },
    );
  }
}
