import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/app_state.dart';
import '../theme/app_theme.dart';

class RoleDemoScreen extends StatelessWidget {
  const RoleDemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: Text(state.isAdmin ? 'Admin Panel' : 'Technician App'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(
                state.isAdmin
                    ? 'Admin Dashboard'
                    : 'Technician Dashboard',
              ),
              subtitle: Text(
                state.isAdmin
                    ? 'Manage requests, charges and service flow'
                    : 'Receive and progress nearby customer jobs',
              ),
              leading: Icon(
                state.isAdmin
                    ? Icons.admin_panel_settings
                    : Icons.engineering,
                color: AppTheme.blue,
              ),
            ),
          ),
          if (state.activeBooking != null)
            Card(
              child: Column(
                children: [
                  ListTile(
                    title: Text(state.activeBooking!.service),
                    subtitle: Text(
                      '${state.activeBooking!.id} • '
                      '${state.activeBooking!.area}',
                    ),
                    trailing: Text('Rs. ${state.activeBooking!.charge}'),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(
                      state.activeBooking!.problem.isEmpty
                          ? 'No problem description'
                          : state.activeBooking!.problem,
                    ),
                  ),
                  if (!state.isAdmin)
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: ElevatedButton(
                        onPressed: state.advanceBooking,
                        child: Text(
                          _buttonText(state.activeBooking!.status),
                        ),
                      ),
                    ),
                ],
              ),
            )
          else
            const Padding(
              padding: EdgeInsets.all(30),
              child: Center(child: Text('No active booking yet.')),
            ),
        ],
      ),
    );
  }

  String _buttonText(String status) {
    switch (status) {
      case 'Booking Received':
        return 'ACCEPT JOB';
      case 'Technician Assigned':
        return 'START / ON THE WAY';
      default:
        return 'ADVANCE STATUS';
    }
  }
}
