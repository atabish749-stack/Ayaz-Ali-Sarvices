import 'package:flutter/material.dart';
class ServiceModel {final String name,description;final IconData icon;const ServiceModel(this.name,this.icon,this.description);}
