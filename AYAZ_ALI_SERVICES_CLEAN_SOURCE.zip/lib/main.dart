import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/splash_screen.dart';
import 'services/app_state.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appState = AppState();
  await appState.restore();

  runApp(
    ChangeNotifierProvider<AppState>.value(
      value: appState,
      child: const AyazAliApp(),
    ),
  );
}

class AyazAliApp extends StatelessWidget {
  const AyazAliApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AYAZ ALI SERVICES',
      theme: AppTheme.light,
      home: const SplashScreen(),
    );
  }
}
